// theme color change

let theme = localStorage.getItem('theme')

if(theme == null){
    setTheme('light')
}else{
    setTheme(theme)
}

let themeDots = document.getElementsByClassName("theme-dot");

for (var i=0; themeDots.length > i; i++){
    themeDots[i].addEventListener('click', function(){
        let mode = this.dataset.mode
        console.log("option clicked", mode)
        setTheme(mode)
    })
}


function setTheme(mode){
    if(mode == 'light'){
        document.getElementById('theme-style').href = 'style.css'
    }

    if(mode == 'blue'){
        document.getElementById('theme-style').href = 'color.css'
    }

    
    if(mode == 'green'){
        document.getElementById('theme-style').href = 'third.css'
    }

    
    if(mode == 'purple'){
        document.getElementById('theme-style').href = 'fcolor.css'
    }

        localStorage.setItem('theme', mode)
}





const first_skill = document.querySelector(".skill:first-child");
const sk_counters = document.querySelector(".counter span");
const progress_bars = document.querySelector("skill svg circle");

window.addEventListener("scroll", () =>{
    // console.log("hello");
    skillsCounter();
})
// Scroll Reveal Library

let sr = ScrollReveal({
    duration:2500,
    distance:"60px",
});

sr.reveal(".left-column", {delay: 600});
sr.reveal(".right-column", { origin:"top" ,delay: 600});


sr.reveal("#about-grid", {delay: 300});
sr.reveal("#about-info", { delay: 300});


// skills progress animation bars

function hasReached(el){
    let topPosition = el.getBoudingClientRect().top;
    console.log(topPosition);
}

function skillsCounter(){
    // console.log("you have reached");
    hasReached(first_skill);
}